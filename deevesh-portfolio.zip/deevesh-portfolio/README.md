# Deevesh Nemade — Portfolio

Plain HTML, CSS and JavaScript. No build step.

## Run in VS Code
1. Open this folder in VS Code (File > Open Folder).
2. Install the "Live Server" extension.
3. Right-click index.html > Open with Live Server.

You can also just double-click index.html.

## Files
- index.html: page content
- style.css: all styling (colour tokens at the top of the file)
- script.js: theme toggle, menu, scroll effects, cursor fluid background, copy-email
